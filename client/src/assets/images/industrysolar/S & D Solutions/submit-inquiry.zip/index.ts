// supabase/functions/submit-inquiry/index.ts

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req: Request) => {
  // Allow only POST requests
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  try {
    const body = await req.json();
    const {
      name,
      email,
      phone,
      inquiry_type,
      message,
      recaptcha_token,
    } = body;

    // Required fields check
    if (!name || !email || !inquiry_type || !message || !recaptcha_token) {
      return new Response("Missing required fields", { status: 400 });
    }

    // Step 1: Verify reCAPTCHA v3
    const verifyRes = await fetch("https://www.google.com/recaptcha/api/siteverify", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `secret=${Deno.env.get("6Lfxv1gsAAAAAPaDVAznptk2sVYKPA3zAfHDlNVS")}&response=${recaptcha_token}`,
    });
    const verifyData = await verifyRes.json();

    console.log("reCAPTCHA request body sent:", `secret=...&response=${recaptcha_token.substring(0,20)}...`);
    console.log("reCAPTCHA raw response status:", verifyRes.status);
    console.log("reCAPTCHA full JSON response:", JSON.stringify(verifyData, null, 2));

    // if (!verifyData.success || verifyData.score < 0.1) {
    //   return new Response("reCAPTCHA verification failed or low score", { status: 400 });
    // }

    // Change this line (around line ~30–40):
    if (!verifyData.success || verifyData.score < 0.3) {  // ← was 0.5, now 0.3 or even 0.1
      console.log("Rejected - score:", verifyData.score, "errors:", verifyData["error-codes"]);
      return new Response(`reCAPTCHA failed (score: ${verifyData.score || 'unknown'})`, { status: 400 });
    }

    // Step 2: Connect to Supabase (use service role key for bypass RLS)
    const supabase = createClient(
      Deno.env.get("https://riflxhbxduomczyszbmw.supabase.co")!,
      Deno.env.get("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJpZmx4aGJ4ZHVvbWN6eXN6Ym13Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2OTEwMDAwNywiZXhwIjoyMDg0Njc2MDA3fQ.lmT6KLwje7TQl-EiomxdIXuC0UvI0K16_wkZuAqISmU")!
    );

    // Insert inquiry
    const { error } = await supabase.from("inquiries").insert([
      {
        name,
        email,
        phone,
        inquiry_type,
        message,
        recaptcha_token, // Optional: for logging
      },
    ]);

    if (error) {
      throw error;
    }

    // Step 3: Send Emails using Resend
    const resendApiKey = Deno.env.get("re_2UuFD37D_9Ba9LLEv2Msc58bnGKMGLrUg");
    const fromEmail = "S&D Solutions <no-reply@sdsolutions.lk>"; // Update domain

    // Admin notification email
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: fromEmail,
        to: ["admin@sdsolutions.lk"], // ← Your admin email(s)
        subject: `New Inquiry: ${name} - ${inquiry_type}`,
        html: `
          <h2>New Contact Form Submission</h2>
          <p><strong>Name:</strong> ${name}</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Phone:</strong> ${phone || "Not provided"}</p>
          <p><strong>Type:</strong> ${inquiry_type}</p>
          <p><strong>Message:</strong><br>${message.replace(/\n/g, "<br>")}</p>
        `,
      }),
    });

    // Auto-reply to user
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: fromEmail,
        to: email,
        subject: "Thank You for Your Inquiry – S&D Solutions",
        html: `
          <p>Hi ${name},</p>
          <p>Thank you for reaching out to us! Your inquiry has been received.</p>
          <p>We will review it and get back to you within 24 hours.</p>
          <p>Best regards,<br>The S&D Solutions Team<br><a href="https://sdsolutions.lk">sdsolutions.lk</a></p>
        `,
      }),
    });

    // Optional: SMS via Twilio (uncomment and configure)
    /*
    const twilioSid = Deno.env.get("TWILIO_SID");
    const twilioToken = Deno.env.get("TWILIO_AUTH_TOKEN");
    const twilioPhone = Deno.env.get("TWILIO_PHONE_NUMBER");

    if (phone) {
      await fetch(`https://api.twilio.com/2010-04-01/Accounts/${twilioSid}/Messages.json`, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Authorization: `Basic ${btoa(`${twilioSid}:${twilioToken}`)}`,
        },
        body: new URLSearchParams({
          From: twilioPhone,
          To: phone,
          Body: `Thank you for your inquiry, ${name}! We'll reply soon. - S&D Solutions`,
        }),
      });
    }
    */

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error(err);
    return new Response("Internal server error", { status: 500 });
  }
});