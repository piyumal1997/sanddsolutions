
import React from 'react';
import { BrandInfo } from '../types';

interface HeroProps {
  brand: BrandInfo;
}

const Hero: React.FC<HeroProps> = ({ brand }) => {
  return (
    <section className="relative pt-32 pb-40 lg:pt-48 lg:pb-56 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://picsum.photos/seed/agency/1920/1080" 
          alt="Background" 
          className="w-full h-full object-cover opacity-10"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/80 to-slate-50"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-blue-50 text-blue-600 text-sm font-semibold mb-6 animate-bounce">
            <span className="flex h-2 w-2 rounded-full bg-blue-600 mr-2"></span>
            Currently accepting new projects
          </div>
          
          <h1 className="text-5xl md:text-7xl font-heading font-extrabold text-slate-900 mb-6 tracking-tight leading-tight">
            We bring your <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">Vision</span> to Life
          </h1>
          
          <p className="text-xl text-slate-600 mb-10 max-w-2xl mx-auto leading-relaxed">
            {brand.description}
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <button className="w-full sm:w-auto px-8 py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all transform hover:-translate-y-1 shadow-xl shadow-slate-200">
              View Our Work
            </button>
            <button className="w-full sm:w-auto px-8 py-4 bg-white text-slate-900 border-2 border-slate-200 rounded-2xl font-bold hover:bg-slate-50 transition-all">
              Contact Us
            </button>
          </div>

          <div className="mt-16 flex items-center justify-center space-x-6 text-slate-400 grayscale opacity-60">
             <span className="font-heading font-bold text-2xl tracking-widest">FACEBOOK</span>
             <span className="font-heading font-bold text-2xl tracking-widest">INSTAGRAM</span>
             <span className="font-heading font-bold text-2xl tracking-widest">LINKEDIN</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
