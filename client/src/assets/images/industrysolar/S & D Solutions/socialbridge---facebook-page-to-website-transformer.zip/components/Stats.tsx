
import React from 'react';

interface StatsProps {
  stats: {
    followers: string;
    likes: string;
    rating: number;
  };
}

const Stats: React.FC<StatsProps> = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="glass-card p-8 rounded-3xl shadow-xl shadow-blue-100/50 flex flex-col items-center text-center">
        <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mb-4">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
        </div>
        <span className="text-3xl font-heading font-bold text-slate-900">{stats.followers}</span>
        <span className="text-sm font-medium text-slate-500 uppercase tracking-wider mt-1">Total Followers</span>
      </div>

      <div className="glass-card p-8 rounded-3xl shadow-xl shadow-blue-100/50 flex flex-col items-center text-center">
        <div className="w-12 h-12 bg-pink-100 text-pink-600 rounded-2xl flex items-center justify-center mb-4">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
          </svg>
        </div>
        <span className="text-3xl font-heading font-bold text-slate-900">{stats.likes}</span>
        <span className="text-sm font-medium text-slate-500 uppercase tracking-wider mt-1">Page Likes</span>
      </div>

      <div className="glass-card p-8 rounded-3xl shadow-xl shadow-blue-100/50 flex flex-col items-center text-center">
        <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mb-4">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
          </svg>
        </div>
        <span className="text-3xl font-heading font-bold text-slate-900">{stats.rating}/5.0</span>
        <span className="text-sm font-medium text-slate-500 uppercase tracking-wider mt-1">Average Review</span>
      </div>
    </div>
  );
};

export default Stats;
