
import React from 'react';
import { BrandInfo } from '../types';

interface AboutProps {
  brand: BrandInfo;
}

const About: React.FC<AboutProps> = ({ brand }) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
      <div>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-slate-900 mb-6">About Our Journey</h2>
        <p className="text-lg text-slate-600 mb-8 leading-relaxed">
          At {brand.name}, we believe that every brand has a unique story waiting to be told. 
          Founded on the principles of innovation and aesthetic excellence, our studio has 
          evolved from a small design boutique to a full-service digital presence powerhouse.
        </p>
        
        <div className="space-y-6">
          <div className="flex items-start space-x-4">
            <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center flex-shrink-0">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
            <div>
              <h4 className="font-bold text-slate-900">Headquarters</h4>
              <p className="text-slate-500">{brand.location}</p>
            </div>
          </div>

          <div className="flex items-start space-x-4">
            <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center flex-shrink-0">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
            </div>
            <div>
              <h4 className="font-bold text-slate-900">Get in Touch</h4>
              <p className="text-slate-500">{brand.contact}</p>
            </div>
          </div>

          <div className="flex items-start space-x-4">
            <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center flex-shrink-0">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h4 className="font-bold text-slate-900">Studio Hours</h4>
              <p className="text-slate-500">Mon - Fri: 9:00 AM - 6:00 PM</p>
            </div>
          </div>
        </div>
      </div>

      <div className="relative">
        <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl">
          <img src="https://picsum.photos/seed/studio-team/1000/1000" alt="Our Studio" className="w-full h-full object-cover" />
        </div>
        <div className="absolute -bottom-8 -right-8 w-48 h-48 bg-blue-600 rounded-3xl p-6 flex flex-col justify-end text-white shadow-xl shadow-blue-200 hidden md:flex">
          <span className="text-4xl font-bold mb-1">10+</span>
          <span className="text-sm font-medium opacity-80 uppercase tracking-wider">Years of Excellence</span>
        </div>
      </div>
    </div>
  );
};

export default About;
