
import React from 'react';
import { SocialPost } from '../types';

interface FeedProps {
  posts: SocialPost[];
}

const Feed: React.FC<FeedProps> = ({ posts }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      {posts.map((post) => (
        <article key={post.id} className="group bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-slate-100">
          <div className="aspect-[4/3] relative overflow-hidden">
            <img 
              src={post.image} 
              alt="Post content" 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute top-4 left-4">
               <span className="px-3 py-1 bg-white/90 backdrop-blur-sm rounded-full text-xs font-bold text-slate-900 shadow-sm">
                 {post.date}
               </span>
            </div>
          </div>
          <div className="p-6">
            <p className="text-slate-600 line-clamp-3 mb-6 leading-relaxed">
              {post.content}
            </p>
            <div className="flex items-center justify-between pt-6 border-t border-slate-50">
              <div className="flex items-center space-x-4">
                <button className="flex items-center space-x-1 text-slate-400 hover:text-pink-500 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                  </svg>
                  <span className="text-sm font-semibold">{post.likes}</span>
                </button>
                <button className="flex items-center space-x-1 text-slate-400 hover:text-blue-500 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.827-1.213L3 20l1.391-3.967A8.013 8.013 0 013 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                </button>
              </div>
              <button className="text-blue-600 font-bold text-sm hover:underline">
                View on Facebook
              </button>
            </div>
          </div>
        </article>
      ))}
    </div>
  );
};

export default Feed;
