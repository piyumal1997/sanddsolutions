
export interface BrandInfo {
  name: string;
  category: string;
  description: string;
  location: string;
  contact: string;
  stats: {
    followers: string;
    likes: string;
    rating: number;
  };
}

export interface SocialPost {
  id: string;
  content: string;
  image?: string;
  date: string;
  likes: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
