
import { GoogleGenAI } from "@google/genai";
import { BrandInfo } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getBrandResponse = async (
  query: string, 
  brand: BrandInfo, 
  history: { role: 'user' | 'model', text: string }[]
) => {
  const model = ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [
      ...history.map(h => ({ role: h.role === 'user' ? 'user' : 'model', parts: [{ text: h.text }] })),
      { role: 'user', parts: [{ text: query }] }
    ],
    config: {
      systemInstruction: `You are a professional brand ambassador for "${brand.name}". 
      Category: ${brand.category}.
      Description: ${brand.description}.
      Location: ${brand.location}.
      Contact: ${brand.contact}.
      Always maintain a helpful, polite, and enthusiastic tone. 
      If asked about something outside the brand scope, politely redirect them back to the brand's services.`,
      temperature: 0.7,
      topK: 40,
      topP: 0.95,
    }
  });

  const response = await model;
  return response.text;
};
