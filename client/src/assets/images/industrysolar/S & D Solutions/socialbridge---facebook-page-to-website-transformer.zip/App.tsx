
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Stats from './components/Stats';
import Feed from './components/Feed';
import About from './components/About';
import Footer from './components/Footer';
import BrandChat from './components/BrandChat';
import { BrandInfo, SocialPost } from './types';

// Mock data representing a high-level FB page state
const INITIAL_BRAND: BrandInfo = {
  name: "Lumina Creative Studio",
  category: "Digital Marketing & Design Agency",
  description: "Crafting digital experiences that inspire and convert. From visual identity to performance marketing, we help brands shine in the digital landscape.",
  location: "San Francisco, CA",
  contact: "hello@lumina-studio.com",
  stats: {
    followers: "42.5K",
    likes: "38.2K",
    rating: 4.9
  }
};

const MOCK_POSTS: SocialPost[] = [
  {
    id: '1',
    content: "We just wrapped up an incredible branding project for a sustainable fashion startup! Stay tuned for the full case study. ✨ #Branding #Design #Sustainability",
    image: "https://picsum.photos/seed/design1/800/600",
    date: "2 days ago",
    likes: 1240
  },
  {
    id: '2',
    content: "The secret to high conversion rates isn't just a pretty website—it's understanding user psychology. Our latest blog post dives deep into UX strategy. Link in bio!",
    image: "https://picsum.photos/seed/ux1/800/600",
    date: "4 days ago",
    likes: 856
  },
  {
    id: '3',
    content: "Monday morning mood at the office. Caffeine + Creative Chaos = Magic. ☕️💻",
    image: "https://picsum.photos/seed/office1/800/600",
    date: "1 week ago",
    likes: 2105
  }
];

const App: React.FC = () => {
  const [brand] = useState<BrandInfo>(INITIAL_BRAND);
  const [posts] = useState<SocialPost[]>(MOCK_POSTS);

  return (
    <div className="min-h-screen flex flex-col relative overflow-x-hidden">
      {/* Background blobs for aesthetic depth */}
      <div className="fixed -top-24 -left-24 w-96 h-96 bg-blue-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse pointer-events-none" />
      <div className="fixed top-1/2 -right-24 w-96 h-96 bg-purple-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse delay-700 pointer-events-none" />
      
      <Header brandName={brand.name} />
      
      <main className="flex-grow">
        <Hero brand={brand} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12 relative z-10">
          <Stats stats={brand.stats} />
        </div>

        <section id="feed" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-slate-900 mb-4">Latest from the Studio</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">See what we've been up to lately. Direct from our social feed to you.</p>
          </div>
          <Feed posts={posts} />
        </section>

        <section id="about" className="py-20 bg-slate-100/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <About brand={brand} />
          </div>
        </section>
      </main>

      <Footer brand={brand} />
      
      {/* Floating AI Chat Assistant */}
      <BrandChat brand={brand} />
    </div>
  );
};

export default App;
